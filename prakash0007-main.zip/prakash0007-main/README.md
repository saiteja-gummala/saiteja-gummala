<h1 align="center">Hi 👋, I'm Sai prakash</h1>
<h3 align="center">A passionate Data Scientist and Machine Learning Engineer from India</h3>

- 🔭 I’m currently working on **Shipment price prediction project**

- 🌱 I’m currently learning **Deep Learning ,Computer vision**

- 👯 I’m looking to collaborate on **OpenSource Projects**

- 🤝 I’m looking for help with **Neuro Engineering project**

- 📝 I regularly write articles on [https://prakash0007.medium.com/](https://prakash0007.medium.com/)

- 💬 Ask me about **Python,Machine Learning and statistics**

- 📫 How to reach me **saipraaksh2488@gmail.com**

- 📄 Know about my experiences [github](github)

- ⚡ Fun fact **I like to play chess and go to the gym often**

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://twitter.com/prakash0007" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="prakash0007" height="30" width="40" /></a>
<a href="https://linkedin.com/in/sai prakash" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="sai prakash" height="30" width="40" /></a>
<a href="https://medium.com/https://prakash0007.medium.com/" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/medium.svg" alt="https://prakash0007.medium.com/" height="30" width="40" /></a>
</p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://www.cprogramming.com/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> </a> <a href="https://www.docker.com/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/docker/docker-original-wordmark.svg" alt="docker" width="40" height="40"/> </a> <a href="https://flask.palletsprojects.com/" target="_blank"> <img src="https://www.vectorlogo.zone/logos/pocoo_flask/pocoo_flask-icon.svg" alt="flask" width="40" height="40"/> </a> <a href="https://git-scm.com/" target="_blank"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> </a> <a href="https://heroku.com" target="_blank"> <img src="https://www.vectorlogo.zone/logos/heroku/heroku-icon.svg" alt="heroku" width="40" height="40"/> </a> <a href="https://www.mongodb.com/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original-wordmark.svg" alt="mongodb" width="40" height="40"/> </a> <a href="https://www.mysql.com/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a> <a href="https://postman.com" target="_blank"> <img src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg" alt="postman" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> <a href="https://www.tensorflow.org" target="_blank"> <img src="https://www.vectorlogo.zone/logos/tensorflow/tensorflow-icon.svg" alt="tensorflow" width="40" height="40"/> </a> </p>

<p><img align="center" src="https://github-readme-stats.vercel.app/api/top-langs?username=prakash0007&show_icons=true&locale=en&layout=compact" alt="prakash0007" /></p>

<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=prakash0007&" alt="prakash0007" /></p>



